#include "d_heap.h"

d_heap::d_heap()
{
    //ctor
}

d_heap::~d_heap()
{
    //dtor
}
