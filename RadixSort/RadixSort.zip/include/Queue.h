#ifndef QUEUE_H
#define QUEUE_H


#ifndef LINKEDLIST_H
#define LINKEDLIST_H
using namespace std;

template <class T>
class Queue{
    public:
        Queue(); //Construct an empty queue
        void enqueue(T element); //Adds an element to the front of the queue
        void dequeue(); //Removes the front element of the queue
        T front(); //Returns the value of the first element in the queue
        bool isEmpty(); //Returns true if the queue is empty

    private:
        struct node{
            T val;
            struct node* next;
        };

        struct node* head;
        struct node* rear;
};

template<class T>
    Queue<T>::Queue(){
        head = NULL;
        rear = NULL;
    }

//Adds a node to the front of the linked list
template<class T>
    void Queue<T>::enqueue(T value){
        struct node* n = new struct node;
        n->val = value;
        n->next = NULL;

        //If the queue is empty set head and rear to the element
        if(head == NULL && rear == NULL){
            head = rear = n;
        }

       else{
            rear->next = n;
            rear = n;
       }
}

template<class T>
    void Queue<T>::dequeue(){
    struct node* n = head;

    //Queue is empty
    if(head == NULL){
        cout<<"Cannot dequeue from an empty queue.";
        return;
    }

    //If there is only one element in the queue
    if(head == rear){
        head = rear = NULL;
    }

    else
        head = head->next;

    //delete [] n;
}

template <class T>
T Queue<T>::front(){
    if(isEmpty()){
        cout<<"Nothing in the front of the queue.";
    }
    else
        return head->val;
}

template <class T>
bool Queue<T>::isEmpty(){
    return (head == NULL);
}


#endif // LINKEDLIST_H
#endif // QUEUE_H
